# Thiên Đạo — Bot UI + Backend

## Cấu trúc
- `bot_service/` : chỉ Discord UI
- `backend_service/` : logic + data

## Chạy local
### Backend
```bash
cd backend_service
pip install -r requirements.txt
python main.py
```

### Bot
```bash
cd bot_service
pip install -r requirements.txt
export DISCORD_TOKEN="..."
export API_BASE_URL="http://127.0.0.1:8000"
python main.py
```
